<?php

$namagrp = 'GRUP VIRAL 18+'; //Nama Grup

$fotogrp = 'https://i.ibb.co/zJ1ZrGH/1.png'; //Foto Grup

$linkgrp = 'https://t.me/LIMAPULUH00'; //Link Grup

?>

